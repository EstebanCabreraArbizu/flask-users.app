from flask import Flask, jsonify, request
from flask_cors import CORS
from flaskext.mysql import MySQL #pip install flask-mysql
import pymysql
 
USUARIOS = [
    {
        'id': '1',
        'nombre': 'cairocoders',
        'apellido': 'Ednalan',
        'correo': 'Olongapo city',
        'contrasena':'1234',
        'nickname':'uwuw',
        'COMUNIDAD_nombre':'UPC'
    },
    {
        'id': '2',
        'nombre': 'cairocoders',
        'apellido': 'Ednalan',
        'correo': 'Olongapo city',
        'contrasena':'12344',
        'nickname':'uwuw2',
        'COMUNIDAD_nombre':'UPC'
    }
]
# configuration
DEBUG = True
 
# instantiate the app
#app = Flask(_name_)
app = Flask(__name__)
app.config.from_object(__name__)
     
mysql = MySQL()
    
app.config['MYSQL_DATABASE_USER'] = 'support'
app.config['MYSQL_DATABASE_PASSWORD'] = 'sistemas20.'
app.config['MYSQL_DATABASE_DB'] = 'dockercrud'
app.config['MYSQL_DATABASE_HOST'] = '3.95.171.216'
mysql.init_app(app)
 
# enable CORS
CORS(app, resources={r'/': {'origins': ''}})
 
 
# sanity check route
@app.route('/ping', methods=['GET'])
def ping_pong():
    return jsonify('pong!')
 
@app.route('/USUARIOS', methods=['GET'])
def all_members():
    return jsonify({
        'status': 'success',
        'USUARIOS': USUARIOS
    })
 
@app.route('/')
def home():
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    try:
        cursor.execute("SELECT * from USUARIOS order by id")
        userslist = cursor.fetchall()
        return jsonify({
            'status': 'success',
            'USUARIOS': userslist
        })
    except Exception as e:
        print(e)
    finally:
        cursor.close() 
        conn.close()
 
@app.route('/insert', methods=['GET', 'POST'])
def insert():
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    response_object = {'status': 'success'}
    if request.method == 'POST':
        post_data = request.get_json(silent=True)
        firstname = post_data.get('nombre')
        lastname = post_data.get('apellido')
        address = post_data.get('correo')
        contra = post_data.get('contraseña')
        nickname=post_data.get('nickname')
        comunidad_university=post_data.get('comunida_universitaria')

 
        print(firstname)
        print(lastname)
        print(address)
        print(contra)
        print(nickname)
        print(comunidad_university)
 
        sql = "INSERT INTO USUARIOS(firstname,lastname,address,contra,nickname,comunidad_university) VALUES(%s, %s, %s)"
        data = (firstname, lastname, address,contra,nickname,comunidad_university)
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute(sql, data)
        conn.commit()
 
        response_object['message'] = "Successfully Added"
    return jsonify(response_object)
 
@app.route('/edit/<string:id>', methods=['GET', 'POST'])
def edit(id):
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    print(id)
    cursor.execute("SELECT * FROM USUARIOS WHERE id = %s", [id])
    row = cursor.fetchone() 
 
    return jsonify({
        'status': 'success',
        'edituser': row
    })
 
@app.route('/update', methods=['GET', 'POST'])
def update():
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    response_object = {'status': 'success'}
    if request.method == 'POST':
        post_data = request.get_json(silent=True)
        edit_id = post_data.get('edit_id')
        edit_firstname = post_data.get('edit_firstname')
        edit_lastname = post_data.get('edit_lastname')
        edit_address = post_data.get('edit_address')
    
 
        print(edit_firstname)
        print(edit_lastname)
     
 
        cursor.execute ("UPDATE USUARIOS SET firstname=%s, lastname=%s, address=%s WHERE id=%s",(edit_firstname, edit_lastname, edit_address, edit_id))
        conn.commit()
        cursor.close()
 
        response_object['message'] = "Successfully Updated"
    return jsonify(response_object)
 
@app.route('/delete/<string:id>', methods=['GET', 'POST'])
def delete(id):
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
   
    response_object = {'status': 'success'}
 
    cursor.execute("DELETE FROM USUARIOS WHERE id = %s", [id])
    conn.commit()
    cursor.close()
    response_object['message'] = "Successfully Deleted"
    return jsonify(response_object)
 
if __name__ == '__main__':
    app.run()