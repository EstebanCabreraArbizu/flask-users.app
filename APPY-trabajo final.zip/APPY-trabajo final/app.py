from flask import Flask, render_template, request, redirect, url_for, flash
from flask_mysqldb import MySQL

app = Flask(__name__)
#Mysql connection
app.config['MYSQL_HOST']='54.242.229.17'
app.config['MYSQL_USER']='support'
app.config['MYSQL_PASSWORD']='sistemas20.'
app.config['MYSQL_DB']='dockercrud'
mysql = MySQL(app)

#settings

app.secret_key = 'mysecretkey'

@app.route('/')
def Index():
    cur=mysql.connection.cursor()
    cur.execute('SELECT * FROM USUARIOS')
    data = cur.fetchall()
    return render_template('index.html', usuarios=data)

@app.route('/add_contact', methods=['POST'])
def add_contact():
    if request.method == 'POST':
        id=request.form['id']
        nombre=request.form['nombre']
        apellido=request.form['apellido']
        correo=request.form['correo']
        contrasena=request.form['contrasena']
        nickname=request.form['nickname']
        COMUNIDAD_nombre=request.form['COMUNIDAD_nombre']

        cur=mysql.connection.cursor()
        cur.execute('INSERT INTO USUARIOS (id, nombre, apellido, correo, contrasena, nickname, COMUNIDAD_nombre) VALUES (%s, %s, %s, %s, %s, %s, %s)', (id, nombre, apellido, correo, contrasena, nickname, COMUNIDAD_nombre))
        mysql.connection.commit()
        flash('Contact Added succesfully')

        return redirect(url_for('Index'))

        

@app.route('/edit/<id>')
def get_contact(id):
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM USUARIOS WHERE id = %s', (id))
    data = cur.fetchall()
    print(data)
    return render_template('edit-user.html',usuarios=data[0])

@app.route('/update/<id>', methods={'POST'})
def update_usuario(id):
    if request.method == 'POST':
        id=request.form['id']
        nombre=request.form['nombre']
        apellido=request.form['apellido']
        correo=request.form['correo']
        contrasena=request.form['contrasena']
        nickname=request.form['nickname']
        COMUNIDAD_nombre=request.form['COMUNIDAD_nombre']
        cur=mysql.connection.cursor()
        cur.execute("""
            UPDATE USUARIOS
            SET nombre=%s, 
                apellido=%s, 
                correo=%s,
                contrasena=%s,
                nickname=%s,
                COMUNIDAD_nombre=%s
            WHERE id=%s""",(nombre,apellido,correo,contrasena,nickname,COMUNIDAD_nombre,id))
        mysql.connection.commit()
        flash('Usuario actualizado satisfactoriamente')
        return redirect(url_for('Index'))
        

@app.route('/delete/<string:id>')
def delete_contact(id):
   cur=mysql.connection.cursor()
   cur.execute('DELETE FROM USUARIOS WHERE id = %s', (id,))
   mysql.connection.commit()
   return redirect(url_for('Index'))
   flash('Contacto removido')

if __name__ == '__main__':
    app.run(port = 3000, debug = True)